%##################################################################################
% This is the Main code for executing the SERMON model.                           %
%##################################################################################
clc
clear
close all

%% load datasets; d is delay; 0<=d<=1000
%load 'D:\Datasets\Hepmass2m'; d=0; I = 28; name='Hepmass';
load 'D:\Datasets\electricitypricing'; d=0; I = 8; name='Electricity'; 
%data=load('D:\Datasets\3Dprinting1.txt');  d=3; d=5; I = 12; name='3DPrint';

%% run SERMON
performance = sermon(data,I,name,d);
disp(performance)
%##################################################################################